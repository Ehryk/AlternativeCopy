// background.js

// Called when the user clicks on the browser action.
chrome.browserAction.onClicked.addListener(function(tab) {
  var href = tab.url;
  copyToClipboard(href);
});

function copyToClipboard(href) {
  var shortened = shortenUrl(href);

  var script = "console.log('URL to Copy: {url}');" +
    "_temp_element = document.createElement('textarea');" +
    "_temp_element.value = '{url}';" +
    "_temp_element.setAttribute('readonly', '');" +
    "_temp_element.style.position = 'absolute';" +
    "_temp_element.style.left = '-9999px';" +
    "document.body.appendChild(_temp_element);" +
    "_temp_element.select();" +
    "document.execCommand('copy');" +
    "document.body.removeChild(_temp_element);" +
    "delete _temp_element;";

  script = script.replace(/{url}/g, shortened);

  chrome.tabs.executeScript({
    code: script
  });
}

function shortenUrl(href) {
  var host = getHost(href).toLowerCase();
  if (host.indexOf("ebay") > -1) {
    href = href.replace(/(.*\/itm\/)([^/]*)\/(.*)/, '$1$3');
    href = removeQueryString(href);
  }
  else {
    href = removeQueryString(href);
  }
  return href;
}

function getHost(href){
  return Object.assign(document.createElement('a'), { href: href }).host;
}

function removeQueryString(href) {
  if (href.indexOf('?' > -1)) {
    href = href.split('?')[0];
  }
  return href;
}

chrome.commands.onCommand.addListener(function(command) {
  if (command === "copy-to-clipboard") {
    copyToClipboard("Test");
  }
});
